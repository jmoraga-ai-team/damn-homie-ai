# Credits

The answer style in Damn Homie AI (section 2 of SKILL.md) is built on the open-source skill
**i-have-adhd** by Ayoub Ghriss: https://github.com/ayghri/i-have-adhd

It is MIT licensed. Its license is in LICENSE-i-have-adhd.txt in this folder.

Damn Homie AI adds: Save Point memory (Google Drive, built-in memory, Save Code), merge and daily tidy,
brain dump to game plan, quests and XP, skill tree, train of thought, parking lot, brainstorm mode,
instant stop, check first, My Rules, Decisions and Wins logs, and coach notes.
